import networkx as nx


class Ifc2Graph:
    def __init__(self) -> None:
        print("IFC2graph still in progress")
        pass
