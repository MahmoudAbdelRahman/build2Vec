from .build2vec import Build2Vec
from .ifc2graph import Ifc2Graph
from importlib import metadata

__version__ = metadata.version('build2vec')