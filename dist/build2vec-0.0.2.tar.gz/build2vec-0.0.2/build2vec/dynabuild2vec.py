


class DynaBuild2Vec:
    def __init__(self) -> None:
        pass